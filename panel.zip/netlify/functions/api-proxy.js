// Netlify Function — SMM Provider API Proxy
// Bypasses CORS restrictions for provider API calls

exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { url, key, action, ...params } = JSON.parse(event.body || '{}');
    
    if (!url || !key) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing url or key' }) };
    }

    // Build form data for SMM panel API (standard format)
    const formData = new URLSearchParams();
    formData.append('key', key);
    formData.append('action', action || 'services');
    Object.keys(params).forEach(k => formData.append(k, params[k]));

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: formData.toString()
    });

    const text = await response.text();
    
    // Try to parse as JSON
    let data;
    try {
      data = JSON.parse(text);
    } catch(e) {
      return { statusCode: 200, headers, body: JSON.stringify({ error: 'Invalid JSON from provider', raw: text.slice(0, 500) }) };
    }

    return { statusCode: 200, headers, body: JSON.stringify(data) };
    
  } catch (err) {
    return { 
      statusCode: 500, 
      headers, 
      body: JSON.stringify({ error: err.message }) 
    };
  }
};
