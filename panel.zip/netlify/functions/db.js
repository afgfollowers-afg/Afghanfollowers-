// Cross-device sync - stores data in Netlify function memory
// Data persists as long as function instance is alive (~15 min)
// For permanent storage, use JSONbin or GitHub Gist

let SHARED_DATA = { smm_users: [], smm_orders: [], smm_ts: 0 };

exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod === 'GET') {
    return { statusCode: 200, headers, body: JSON.stringify(SHARED_DATA) };
  }

  if (event.httpMethod === 'POST') {
    try {
      const body = JSON.parse(event.body || '{}');
      // Merge - keep data with more users
      if (body.smm_users && Array.isArray(body.smm_users)) {
        if (body.smm_users.length >= (SHARED_DATA.smm_users || []).length) {
          SHARED_DATA.smm_users = body.smm_users;
        }
      }
      if (body.smm_orders && Array.isArray(body.smm_orders)) {
        if (body.smm_orders.length >= (SHARED_DATA.smm_orders || []).length) {
          SHARED_DATA.smm_orders = body.smm_orders;
        }
      }
      SHARED_DATA.smm_ts = Date.now();
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true, users: SHARED_DATA.smm_users.length }) };
    } catch(e) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: e.message }) };
    }
  }

  return { statusCode: 405, headers, body: '{}' };
};
